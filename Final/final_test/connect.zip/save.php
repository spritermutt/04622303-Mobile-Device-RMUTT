<?php
include 'connect.php';

$name = $_POST['name'];
$phone = $_POST['phone'];
$map = $_POST['map'];
$sql = "SELECT * FROM students WHERE phone = '$phone'";

$result = mysqli_query($con, $sql);
$count = mysqli_num_rows($result);

if ($count == 1) {
    echo json_encode('Error');
} else {
    $insert = "INSERT INTO students(name,phone,map)VALUES('$name','$phone','$map')";
    $query = mysqli_query($con, $insert);
    if ($query) {
        echo json_encode('Success');
    }
}
?>
