<?php
include 'connect.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

try {
    $sql = "SELECT id, name, phone, map FROM students ORDER BY id ASC";
    $result = $con->query($sql);
    $students = array();

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $students[] = $row;
        }
    }
    
    echo json_encode($students);
    
} catch (Exception $e) {
    echo json_encode(array('error' => $e->getMessage()));
}

$con->close();
?>
